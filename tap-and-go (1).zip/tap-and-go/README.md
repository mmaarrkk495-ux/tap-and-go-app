# Tap and Go

A Pen created on CodePen.

Original URL: [https://codepen.io/Mark-Mark-the-bold/pen/GgpMzQa](https://codepen.io/Mark-Mark-the-bold/pen/GgpMzQa).

